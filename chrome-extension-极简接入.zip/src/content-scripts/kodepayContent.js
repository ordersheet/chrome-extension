import {KodepayContent} from 'kodepay'
KodepayContent.kodepay_content_start_listener()