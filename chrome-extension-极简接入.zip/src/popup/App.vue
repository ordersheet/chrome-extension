<template>
  <div class="example">
    hello, this is chrome extension vue
    <button @click="openPaymentPage('prod_640ff4a7dc6b4a13')">打开支付页面</button>
    <button @click="openLoginPage">打开登录页面</button>
    <button @click="openBillManagementPage">打开账单页面</button>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  methods : {
    openPaymentPage(price_id) {
      // 当你有多个套餐时，可以将套餐的ID作为参数传递给kodepay,我这里只有一个示例，
      /* eslint-disable */
      chrome.runtime.sendMessage({target:'BACKGROUND', type:'open-payment-page', 'price_id': price_id}, function(response) {
        console.log(response);
      });
    },
    openLoginPage() {
      /* eslint-disable */
      chrome.runtime.sendMessage({target:'BACKGROUND', type:'open-login-page'}, function(response) {
        console.log(response);
      });
    },
    openBillManagementPage() {
      /* eslint-disable */
      chrome.runtime.sendMessage({target:'BACKGROUND', type:'open-bill-management-page'}, function(response) {
        console.log(response);
      });
    }
  },
}
</script>
<style scoped>
.example {
  align-items: center;
  display: flex;
  position: relative;
  margin: 0 16px;
}
</style>