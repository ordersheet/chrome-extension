/* eslint-disable */
// service_worker
import {Kodepay} from "kodepay";
// example: const kodepay_client = Kodepay.kodepay(application_id, extension_id, 'mode')
//You can find the application_id in the Developer Settings page
//You can find the extension_id in the extension page
const kodepay_client = Kodepay.kodepay('0901f27e-7a29-11ee-91c8-b6a875f756a9', '9fa943c6-7a29-11ee-a5cf-2ebbac903f21', 'development');
// get user info
kodepay_client.get_user_info().then((user) => {
  console.log(user);
});
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.target === 'BACKGROUND') {
    if (request.type === 'open-payment-page') {
      kodepay_client.open_payment_page(request.price_id).then(res => {
        sendResponse(res)
      })
      return true;
    }
    if (request.type === 'open-login-page') {
      kodepay_client.open_login_page().then(res => {
        sendResponse(res)
      })
      return true;
    }
    if (request.type === 'open-bill-management-page') {
      kodepay_client.open_user_management_page().then(res => {
        sendResponse(res)
      })
      return true;
    }
  }
});